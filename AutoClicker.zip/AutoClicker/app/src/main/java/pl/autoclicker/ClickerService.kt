package pl.autoclicker

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Bitmap
import android.os.Build
import android.view.Display
import android.widget.FrameLayout
import kotlinx.coroutines.withContext
import android.content.Intent
import android.graphics.Color
import android.graphics.Path
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.SystemClock
import android.text.InputType
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.widget.CheckBox
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.RadioButton
import android.widget.RadioGroup
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlin.coroutines.resume
import kotlin.math.abs

class ClickerService : AccessibilityService() {

    companion object {
        @Volatile
        var instance: ClickerService? = null

        // wykrywanie liczy "kratki" 16x16 px, w których jest co najmniej CELL_MIN pikseli z kolorem nazwy
        const val CELL = 16
        const val CELL_MIN = 10
    }

    private lateinit var wm: WindowManager
    private val scope = CoroutineScope(Dispatchers.Main + SupervisorJob())
    private var job: Job? = null

    private val steps = mutableListOf<Step>()
    private val markers = LinkedHashMap<Step, TextView>()
    private var bar: View? = null
    private var playBtn: TextView? = null
    private var editor: View? = null
    private var settings = Settings()
    private var running = false
    private var overlayShown = false
    private var channelRotation = 0
    private var statusTv: TextView? = null
    private var barP: WindowManager.LayoutParams? = null
    private var frame: View? = null
    private var frameP: WindowManager.LayoutParams? = null
    private var cross: View? = null
    private var lastPkg: String? = null      // ostatnia aplikacja na wierzchu (poza systemem i naszą)
    private var autoOpened = false           // panel został otwarty automatycznie po wejściu do gry
    private var learnBase: Bitmap? = null    // zrzut "pustego pola" do kalibracji kolorów
    @Volatile private var mobsOn = false     // na ekranie są potwory (z histerezą)
    @Volatile private var lootOn = false     // na ziemi leżą przedmioty (z histerezą)
    @Volatile private var lastMobSeen = 0L
    @Volatile private var lastLootSeen = 0L
    private var collapsed = false            // panel zwinięty do małej bańki
    private var bubble: TextView? = null
    private var bubbleP: WindowManager.LayoutParams? = null
    private var target = 0                   // cel pipety i 🎓: 0 = potwory, 1 = przedmioty
    private var targetBtn: TextView? = null

    override fun onServiceConnected() {
        instance = this
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
    }

    private fun ignoredPkg(p: String): Boolean =
        p == "android" || p.startsWith("com.android.") || p.contains("systemui") ||
                p.contains("inputmethod") || isLauncher(p)

    private fun isLauncher(p: String): Boolean =
        p.contains("launcher") || p.endsWith(".home") || p.contains(".home.")

    /** Po wejściu do gry: rozpoznaje ją, wczytuje jej profil i pokazuje panel. */
    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event == null || event.eventType != AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) return
        val pkg = event.packageName?.toString() ?: return
        if (pkg == packageName) return
        if (ignoredPkg(pkg)) {
            lastPkg = null
            if (overlayShown && autoOpened && isLauncher(pkg)) hideOverlay()
            return
        }
        val prev = lastPkg
        lastPkg = pkg
        if (!Store.autoEnabled(this) || pkg == prev) return

        var name = Store.boundProfile(this, pkg)
        if (name == null) {
            val hit = Profiles.builtinFor(pkg)
            if (hit != null) {
                Store.bind(this, pkg, hit)
                name = hit
            }
        }
        if (name == null) {
            // inna aplikacja: chowamy panel, jeśli sami go otworzyliśmy
            if (overlayShown && autoOpened) hideOverlay()
            return
        }
        if (Store.activeProfile(this) != name) {
            val json = Profiles.get(this, name)
            if (json != null) {
                hideOverlay()
                if (Profiles.load(this, json)) {
                    Store.setActiveProfile(this, name)
                    toast("Wykryto grę – wczytano profil „$name”")
                }
            }
        }
        if (!overlayShown) {
            showOverlay()
            autoOpened = true
        }
    }

    override fun onInterrupt() {
        stopRun()
    }

    override fun onUnbind(intent: Intent?): Boolean {
        hideOverlay()
        instance = null
        return super.onUnbind(intent)
    }

    override fun onDestroy() {
        scope.cancel()
        super.onDestroy()
    }

    // ------------------------------------------------------------ overlay

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun params(w: Int, h: Int, focusable: Boolean = false): WindowManager.LayoutParams {
        var flags = WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN
        if (!focusable) flags = flags or WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
        return WindowManager.LayoutParams(
            w, h,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            flags,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.START }
    }

    fun showOverlay() {
        if (overlayShown) return
        overlayShown = true
        noteOrientation()
        steps.clear()
        steps.addAll(Store.loadSteps(this))
        settings = Store.loadSettings(this)
        buildBar()
        steps.forEach { addMarker(it) }
        refreshMarkers()
    }

    fun hideOverlay() {
        if (!overlayShown) return
        stopRun()
        closeEditor()
        removeCalibViews()
        markers.values.forEach { runCatching { wm.removeView(it) } }
        markers.clear()
        bar?.let { runCatching { wm.removeView(it) } }
        bar = null
        bubble?.let { runCatching { wm.removeView(it) } }
        bubble = null
        bubbleP = null
        collapsed = false
        overlayShown = false
        autoOpened = false
    }

    private fun buildBar() {
        // dwa rzędy przycisków w ramce w kolorze złota, żeby panel był widoczny i mieścił się na ekranie
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = GradientDrawable().apply {
                setColor(0xF2121820.toInt()); cornerRadius = dp(14).toFloat()
                setStroke(dp(2), 0xFFFFC107.toInt())
            }
            setPadding(dp(6), dp(6), dp(6), dp(6))
        }
        val r1 = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val r2 = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        row.addView(r1)
        row.addView(r2)
        fun btn(t: String, onClick: () -> Unit) = TextView(this).apply {
            text = t; setTextColor(Color.WHITE); textSize = 20f
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
            setPadding(dp(10), dp(9), dp(10), dp(9))
            setOnClickListener { onClick() }
        }

        val p = params(WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT)
        p.x = dp(8); p.y = dp(120)

        // uchwyt do przeciągania panelu
        val handle = btn("✥") {}
        var dx = 0f; var dy = 0f; var sx = 0; var sy = 0
        handle.setOnTouchListener { _, ev ->
            when (ev.action) {
                MotionEvent.ACTION_DOWN -> { dx = ev.rawX; dy = ev.rawY; sx = p.x; sy = p.y }
                MotionEvent.ACTION_MOVE -> {
                    p.x = sx + (ev.rawX - dx).toInt(); p.y = sy + (ev.rawY - dy).toInt()
                    wm.updateViewLayout(row, p)
                }
            }
            true
        }

        playBtn = btn("▶") { if (running) stopRun() else startRun() }
        // rząd 1: sterowanie
        r1.addView(handle)
        r1.addView(btn("–") { collapse() })
        r1.addView(playBtn)
        r1.addView(btn("＋") { addStep(Group.MAIN) })
        r1.addView(btn("K＋") { addStep(Group.CHANNEL) })
        r1.addView(btn("⏻") { powerOff() })
        r1.addView(btn("✕") { hideOverlay() })

        // rząd 2: wykrywanie potworów i przedmiotów
        r2.addView(btn("▢") { toggleFrame() })
        targetBtn = btn("P") { toggleTarget() }
        r2.addView(targetBtn)
        r2.addView(btn("💧") { toggleCross() })
        r2.addView(btn("🎓") { learn() })
        r2.addView(btn("🔍") { testDetect() })
        statusTv = TextView(this).apply {
            textSize = 12f; setTextColor(0xFFFFE082.toInt()); gravity = Gravity.CENTER
            typeface = Typeface.DEFAULT_BOLD
            minWidth = dp(56); text = "–"
        }
        r2.addView(statusTv)

        wm.addView(row, p)
        barP = p
        bar = row
    }

    private fun addStep(group: Group) {
        if (running) return
        val m = resources.displayMetrics
        noteOrientation()
        val offset = dp(24) * (steps.size % 6)
        val s = Step(m.widthPixels / 2 + offset, m.heightPixels / 2 + offset, group)
        steps.add(s)
        addMarker(s)
        refreshMarkers()
        Store.saveSteps(this, steps)
    }

    private fun addMarker(s: Step) {
        val size = dp(52)
        val tv = TextView(this).apply {
            gravity = Gravity.CENTER
            setTextColor(Color.WHITE)
            textSize = 15f
            typeface = Typeface.DEFAULT_BOLD
            background = GradientDrawable().apply { shape = GradientDrawable.OVAL }
        }
        val p = params(size, size)
        p.x = s.x - size / 2
        p.y = s.y - size / 2
        tv.tag = p

        var downX = 0f; var downY = 0f; var startX = 0; var startY = 0; var moved = false
        tv.setOnTouchListener { _, ev ->
            when (ev.action) {
                MotionEvent.ACTION_DOWN -> {
                    downX = ev.rawX; downY = ev.rawY; startX = p.x; startY = p.y; moved = false
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = ev.rawX - downX; val dy = ev.rawY - downY
                    if (abs(dx) > dp(6) || abs(dy) > dp(6)) moved = true
                    if (moved) {
                        p.x = startX + dx.toInt(); p.y = startY + dy.toInt()
                        wm.updateViewLayout(tv, p)
                        s.x = p.x + size / 2; s.y = p.y + size / 2
                    }
                }
                MotionEvent.ACTION_UP -> {
                    if (moved) Store.saveSteps(this, steps) else openEditor(s)
                }
            }
            true
        }
        wm.addView(tv, p)
        markers[s] = tv
    }

    private fun refreshMarkers() {
        var m = 0; var k = 0
        for (s in steps) {
            val tv = markers[s] ?: continue
            val label = if (s.group == Group.MAIN) "${++m}" else "K${++k}"
            // P = tylko gdy są potwory, Z = tylko gdy leży przedmiot (zbieranie)
            val tag = if (s.group != Group.MAIN) "" else when (s.cond) {
                Cond.MOBS -> "P"
                Cond.LOOT -> "Z"
                else -> ""
            }
            tv.text = label + tag
            val bg = tv.background as GradientDrawable
            bg.setColor(if (s.group == Group.MAIN) 0xCC1E88E5.toInt() else 0xCCF57C00.toInt())
            // biały pierścień = przytrzymanie
            bg.setStroke(if (s.type == ActionType.HOLD) dp(3) else 0, Color.WHITE)
        }
    }

    private fun updateUi() {
        playBtn?.text = if (running) "■" else "▶"
        bubble?.text = if (running) "■" else "⚙"
        if (!running) statusTv?.text = "–"
        markers.values.forEach { tv ->
            val p = tv.tag as WindowManager.LayoutParams
            p.flags = if (running) p.flags or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
            else p.flags and WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE.inv()
            // podczas pracy punkty są ukryte, żeby nie zakłócały wykrywania kolorów
            tv.visibility = if (running || collapsed) View.INVISIBLE else View.VISIBLE
            runCatching { wm.updateViewLayout(tv, p) }
        }
    }

    // ------------------------------------------------------------ edytor punktu

    private fun closeEditor() {
        editor?.let { runCatching { wm.removeView(it) } }
        editor = null
    }

    private fun openEditor(s: Step) {
        if (running) return
        closeEditor()

        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(16), dp(16), dp(16))
        }
        fun label(t: String) = TextView(this).apply {
            text = t; setTextColor(0xFF444444.toInt()); textSize = 13f
            setPadding(0, dp(10), 0, 0)
        }
        fun num(v: Long) = EditText(this).apply {
            inputType = InputType.TYPE_CLASS_NUMBER
            setText(v.toString()); setTextColor(Color.BLACK); setSingleLine()
        }

        val idx = steps.indexOf(s) + 1
        box.addView(TextView(this).apply {
            text = "Punkt $idx"; setTextColor(Color.BLACK); textSize = 18f
            typeface = Typeface.DEFAULT_BOLD
        })

        val cbChannel = CheckBox(this).apply {
            text = "Zmiana kanału (grupa K)"; setTextColor(Color.BLACK)
            isChecked = s.group == Group.CHANNEL
        }
        val cbRotate = CheckBox(this).apply {
            text = "Rotuj: używaj na zmianę z innymi rotującymi"; setTextColor(Color.BLACK)
            isChecked = s.rotate
            visibility = if (cbChannel.isChecked) View.VISIBLE else View.GONE
        }
        cbChannel.setOnCheckedChangeListener { _, c -> cbRotate.visibility = if (c) View.VISIBLE else View.GONE }
        box.addView(cbChannel)
        box.addView(cbRotate)

        val rbTap = RadioButton(this).apply { text = "Naciśnij"; id = View.generateViewId(); setTextColor(Color.BLACK) }
        val rbHold = RadioButton(this).apply { text = "Przytrzymaj"; id = View.generateViewId(); setTextColor(Color.BLACK) }
        val rg = RadioGroup(this).apply {
            orientation = RadioGroup.HORIZONTAL
            addView(rbTap); addView(rbHold)
            check(if (s.type == ActionType.HOLD) rbHold.id else rbTap.id)
        }
        box.addView(label("Akcja"))
        box.addView(rg)

        val holdLabel = label("Jak długo trzymać (ms)")
        val holdEt = num(s.holdMs)
        fun syncHold() {
            val v = if (rbHold.isChecked) View.VISIBLE else View.GONE
            holdLabel.visibility = v; holdEt.visibility = v
        }
        rg.setOnCheckedChangeListener { _, _ -> syncHold() }
        syncHold()
        box.addView(holdLabel); box.addView(holdEt)

        val countEt = num(s.count.toLong())
        val gapEt = num(s.gapMs)
        val delayEt = num(s.delayAfterMs)
        box.addView(label("Ile razy nacisnąć / przytrzymać")); box.addView(countEt)
        box.addView(label("Przerwa między powtórzeniami (ms)")); box.addView(gapEt)
        box.addView(label("Pauza po tym punkcie (ms)")); box.addView(delayEt)

        val rbAlways = RadioButton(this).apply { text = "Zawsze"; id = View.generateViewId(); setTextColor(Color.BLACK) }
        val rbMobs = RadioButton(this).apply { text = "Tylko gdy są potwory (bicie)"; id = View.generateViewId(); setTextColor(Color.BLACK) }
        val rbLoot = RadioButton(this).apply { text = "Tylko gdy leży przedmiot (zbieranie)"; id = View.generateViewId(); setTextColor(Color.BLACK) }
        val rgCond = RadioGroup(this).apply {
            orientation = RadioGroup.VERTICAL
            addView(rbAlways); addView(rbMobs); addView(rbLoot)
            check(
                when (s.cond) {
                    Cond.MOBS -> rbMobs.id
                    Cond.LOOT -> rbLoot.id
                    else -> rbAlways.id
                }
            )
        }
        box.addView(label("Kiedy wykonywać (działa przy włączonym wykrywaniu i zapisanych kolorach)"))
        box.addView(rgCond)

        val buttons = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(0, dp(14), 0, 0)
        }
        fun action(t: String, color: Int, onClick: () -> Unit) = TextView(this).apply {
            text = t; setTextColor(Color.WHITE); gravity = Gravity.CENTER
            typeface = Typeface.DEFAULT_BOLD
            setPadding(dp(8), dp(12), dp(8), dp(12))
            background = GradientDrawable().apply { setColor(color); cornerRadius = dp(10).toFloat() }
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
                .apply { setMargins(dp(4), 0, dp(4), 0) }
            setOnClickListener { onClick() }
        }
        buttons.addView(action("Usuń", 0xFFD32F2F.toInt()) {
            markers.remove(s)?.let { runCatching { wm.removeView(it) } }
            steps.remove(s)
            refreshMarkers()
            Store.saveSteps(this, steps)
            closeEditor()
        })
        buttons.addView(action("Anuluj", 0xFF757575.toInt()) { closeEditor() })
        buttons.addView(action("Zapisz", 0xFF2E7D32.toInt()) {
            s.group = if (cbChannel.isChecked) Group.CHANNEL else Group.MAIN
            s.rotate = cbChannel.isChecked && cbRotate.isChecked
            s.type = if (rbHold.isChecked) ActionType.HOLD else ActionType.TAP
            s.holdMs = (holdEt.text.toString().toLongOrNull() ?: 500L).coerceIn(1L, 60000L)
            s.count = (countEt.text.toString().toIntOrNull() ?: 1).coerceIn(1, 9999)
            s.gapMs = (gapEt.text.toString().toLongOrNull() ?: 100L).coerceAtLeast(0L)
            s.delayAfterMs = (delayEt.text.toString().toLongOrNull() ?: 500L).coerceAtLeast(0L)
            s.cond = when {
                rbMobs.isChecked -> Cond.MOBS
                rbLoot.isChecked -> Cond.LOOT
                else -> Cond.ALWAYS
            }
            refreshMarkers()
            Store.saveSteps(this, steps)
            closeEditor()
        })
        box.addView(buttons)

        // na ekranie poziomym okno nie może być wyższe niż ekran, inaczej nie da się go przewinąć
        val maxH = (realMetrics().heightPixels * 0.9).toInt()
        val scroll = object : ScrollView(this) {
            override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
                super.onMeasure(
                    widthMeasureSpec,
                    View.MeasureSpec.makeMeasureSpec(maxH, View.MeasureSpec.AT_MOST)
                )
            }
        }.apply {
            background = GradientDrawable().apply { setColor(Color.WHITE); cornerRadius = dp(16).toFloat() }
            addView(box)
        }
        val p = params(dp(320), WindowManager.LayoutParams.WRAP_CONTENT, focusable = true)
        p.gravity = Gravity.CENTER
        p.softInputMode = WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE
        wm.addView(scroll, p)
        editor = scroll
    }

    // ------------------------------------------------------------ uruchamianie

    private fun startRun() {
        if (running) return
        closeEditor()
        removeCalibViews()
        // przy pierwszym starcie zapamiętujemy, do której gry należy aktywny profil
        lastPkg?.let { pkg ->
            val ap = Store.activeProfile(this)
            if (ap != null && Store.boundProfile(this, pkg) == null) {
                Store.bind(this, pkg, ap)
                toast("Profil „$ap” przypisany do tej gry – następnym razem wczyta się sam")
            }
        }
        settings = Store.loadSettings(this)
        Store.saveSteps(this, steps)

        val main = steps.filter { it.group == Group.MAIN }
        val chan = steps.filter { it.group == Group.CHANNEL }
        if (main.isEmpty() && chan.isEmpty()) {
            Toast.makeText(this, "Dodaj najpierw punkt (＋)", Toast.LENGTH_SHORT).show()
            return
        }
        running = true
        updateUi()

        job = scope.launch {
            var cycle = 0
            var lastChannel = SystemClock.elapsedRealtime()
            var clearSince = 0L
            var lootSince = 0L
            val mobDet = settings.colors.isNotEmpty()
            val lootDet = settings.lootColors.isNotEmpty()
            val detect = settings.detectEnabled && (mobDet || lootDet) && Build.VERSION.SDK_INT >= 30
            if (settings.detectEnabled && !detect) {
                toast("Wykrywanie nieaktywne (brak kolorów 💧/🎓 albo Android starszy niż 11) – punkty działają zawsze, kanał zmienia timer")
            }
            mobsOn = false; lootOn = false; lastMobSeen = 0L; lastLootSeen = 0L
            if (detect) launch { detectLoop() }

            while (isActive && (settings.loops == 0 || cycle < settings.loops)) {
                var did = false
                for (s in main) {
                    if (!isActive) break
                    // punkty z warunkiem wykonują się tylko, gdy są potwory / leży przedmiot
                    val ok = !detect || when (s.cond) {
                        Cond.ALWAYS -> true
                        Cond.MOBS -> !mobDet || mobsOn
                        Cond.LOOT -> !lootDet || lootOn
                    }
                    if (ok) {
                        runStep(s)
                        did = true
                    }
                }
                if (did) cycle++

                val now = SystemClock.elapsedRealtime()
                if (detect) {
                    if (chan.isNotEmpty()) {
                        // przedmiot, którego nie da się podnieść, nie blokuje zmiany kanału dłużej niż 20 s
                        if (lootDet && lootOn) {
                            if (lootSince == 0L) lootSince = now
                        } else {
                            lootSince = 0L
                        }
                        val lootBusy = lootDet && lootOn && now - lootSince < 20000L
                        val busy = (mobDet && mobsOn) || lootBusy
                        if (busy) {
                            clearSince = 0L
                        } else {
                            if (clearSince == 0L) clearSince = now
                            if (now - clearSince >= settings.clearSec * 1000L && now - lastChannel >= 15000L) {
                                runChannelSwitch(chan)
                                lastChannel = SystemClock.elapsedRealtime()
                                clearSince = 0L
                                lootSince = 0L
                                mobsOn = false; lootOn = false; lastMobSeen = 0L; lastLootSeen = 0L
                            }
                        }
                    }
                } else {
                    val due = now - lastChannel >= settings.channelEverySec * 1000L
                    if (settings.channelEnabled && chan.isNotEmpty() && due) {
                        runChannelSwitch(chan)
                        lastChannel = SystemClock.elapsedRealtime()
                    }
                }
                // gdy nic nie było do zrobienia (brak potworów), nie kręcimy pętli bez przerwy
                if (!did) delay(300)
            }
            stopRun()
        }
    }

    private suspend fun runChannelSwitch(chan: List<Step>) {
        val rotating = chan.filter { it.rotate }
        val pick = if (rotating.isEmpty()) null else rotating[channelRotation % rotating.size]
        channelRotation++
        for (s in chan) {
            if (!scope.isActive) return
            if (!s.rotate || s === pick) runStep(s)
        }
        // dodatkowy czas na wczytanie postaci po zmianie kanału
        delay(settings.channelExtraMs)
    }

    fun stopRun() {
        job?.cancel()
        job = null
        if (running) {
            running = false
            updateUi()
        }
    }

    private suspend fun runStep(s: Step) {
        val dur = if (s.type == ActionType.HOLD) s.holdMs else settings.tapMs
        for (i in 0 until s.count) {
            gesture(s.x, s.y, dur)
            if (i < s.count - 1) delay(s.gapMs * settings.pauseScale / 100)
        }
        delay(s.delayAfterMs * settings.pauseScale / 100)
    }

    // ------------------------------------------------------------ wykrywanie pustego pola

    private class Learned(val colors: List<Int>, val minCells: Int)

    /**
     * Automatyczna kalibracja: pierwsze stuknięcie 🎓 zapisuje zrzut PUSTEGO pola,
     * drugie zrzut z potworami i przedmiotami. Kolory, których przybyło, to kolory nazw.
     */
    private fun learn() {
        if (running) return
        if (Build.VERSION.SDK_INT < 30) {
            toast("Wykrywanie wymaga Androida 11 lub nowszego")
            return
        }
        scope.launch {
            saveFrame()
            setOverlayVisible(false)
            delay(250)
            val bmp = grab()
            setOverlayVisible(true)
            if (bmp == null) {
                toast("Nie udało się zrobić zrzutu ekranu. Wyłącz i włącz usługę Auto Clicker w ułatwieniach dostępu.")
                return@launch
            }
            val base = learnBase
            if (base == null) {
                learnBase = bmp
                statusTv?.text = "1/2"
                toast("1/2: zapisano puste pole. Gdy pojawią się ${if (target == 0) "potwory (same, bez przedmiotów)" else "przedmioty (same, bez potworów)"} z widocznymi nazwami, stuknij 🎓 ponownie.")
                return@launch
            }
            learnBase = null
            val st = Store.loadSettings(this@ClickerService)
            val res = withContext(Dispatchers.Default) { learnFrom(base, bmp, st) }
            base.recycle()
            bmp.recycle()
            if (res == null) {
                statusTv?.text = "–"
                toast("Nie znalazłem wyraźnych kolorów. Na pierwszym zrzucie ma nie być potworów ani przedmiotów, a na drugim mają być widoczne ich nazwy.")
                return@launch
            }
            val forMobs = target == 0
            updateSettings {
                if (forMobs) {
                    it.colors = res.colors.toMutableList()
                    it.minMob = res.minCells
                } else {
                    it.lootColors = res.colors.toMutableList()
                    it.minLoot = res.minCells
                }
            }
            statusTv?.text = "OK"
            toast("Skalibrowano ${if (forMobs) "potwory" else "przedmioty"}: ${res.colors.size} kolory, próg ${res.minCells} kratek. Sprawdź 🔍 z potworami i bez.")
        }
    }

    private fun learnFrom(a: Bitmap, b: Bitmap, s: Settings): Learned? {
        if (a.width != b.width || a.height != b.height) return null
        val w = a.width
        val h = a.height
        var l = s.region[0]; var t = s.region[1]; var r = s.region[2]; var bt = s.region[3]
        if (r <= l || bt <= t) { l = 0; t = 0; r = w; bt = h }
        l = l.coerceIn(0, w - 1); t = t.coerceIn(0, h - 1)
        r = r.coerceIn(l + 1, w); bt = bt.coerceIn(t + 1, h)
        val rw = r - l
        val rh = bt - t
        val pa = IntArray(rw * rh)
        val pb = IntArray(rw * rh)
        a.getPixels(pa, 0, rw, l, t, rw, rh)
        b.getPixels(pb, 0, rw, l, t, rw, rh)

        fun bin(p: Int) = (((p shr 20) and 15) shl 8) or (((p shr 12) and 15) shl 4) or ((p shr 4) and 15)
        val cntA = IntArray(4096)
        val cntB = IntArray(4096)
        val sr = LongArray(4096)
        val sg = LongArray(4096)
        val sb = LongArray(4096)
        for (p in pa) cntA[bin(p)]++
        for (p in pb) {
            val k = bin(p)
            cntB[k]++
            sr[k] += ((p shr 16) and 255).toLong()
            sg[k] += ((p shr 8) and 255).toLong()
            sb[k] += (p and 255).toLong()
        }
        // kolory, których na drugim zrzucie jest wyraźnie więcej niż na pierwszym
        val order = (0 until 4096)
            .filter { cntB[it] - 3 * cntA[it] > 80 }
            .sortedByDescending { cntB[it] - 3 * cntA[it] }

        val chosen = mutableListOf<Int>()
        for (k in order) {
            val n = cntB[k]
            val cr = (sr[k] / n).toInt()
            val cg = (sg[k] / n).toInt()
            val cb = (sb[k] / n).toInt()
            val hi = maxOf(cr, cg, cb)
            val lo = minOf(cr, cg, cb)
            // interesują nas wyraziste kolory (nazwy), nie szare tło
            if (!(hi - lo > 60 || lo > 190)) continue
            val c = Color.rgb(cr, cg, cb)
            val dup = chosen.any {
                abs(((it shr 16) and 255) - cr) <= 40 && abs(((it shr 8) and 255) - cg) <= 40 &&
                        abs((it and 255) - cb) <= 40
            }
            if (dup) continue
            chosen.add(c)
            if (chosen.size >= 4) break
        }
        if (chosen.isEmpty()) return null

        val ts = Settings(region = s.region, tolerance = s.tolerance)
        val nA = scan(a, ts, chosen, null)
        val nB = scan(b, ts, chosen, null)
        if (nB - nA < 4) return null
        val minCells = (nA + ((nB - nA) / 3).coerceAtLeast(3)).coerceAtMost(nB - 1)
        return Learned(chosen, minCells)
    }

    private fun toast(t: String) {
        Toast.makeText(this, t, Toast.LENGTH_LONG).show()
    }

    private fun updateSettings(block: (Settings) -> Unit) {
        val s = Store.loadSettings(this)
        block(s)
        Store.saveSettings(this, s)
        settings = s
    }

    /** Zwija panel do małej bańki (stuknięcie ją rozwija). Klikanie działa dalej. */
    private fun collapse() {
        if (collapsed || !overlayShown) return
        closeEditor()
        removeCalibViews()
        collapsed = true
        markers.values.forEach { it.visibility = View.INVISIBLE }
        val bp = barP
        bar?.visibility = View.GONE

        val size = dp(44)
        val tv = TextView(this).apply {
            text = if (running) "■" else "⚙"
            textSize = 20f
            gravity = Gravity.CENTER
            setTextColor(Color.WHITE)
            background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(0xEE222222.toInt())
            }
        }
        val p = params(size, size)
        p.x = bp?.x ?: dp(8)
        p.y = bp?.y ?: dp(120)

        var dx = 0f; var dy = 0f; var sx = 0; var sy = 0; var moved = false
        tv.setOnTouchListener { _, ev ->
            when (ev.action) {
                MotionEvent.ACTION_DOWN -> {
                    dx = ev.rawX; dy = ev.rawY; sx = p.x; sy = p.y; moved = false
                }
                MotionEvent.ACTION_MOVE -> {
                    val mx = ev.rawX - dx
                    val my = ev.rawY - dy
                    if (abs(mx) > dp(6) || abs(my) > dp(6)) moved = true
                    if (moved) {
                        p.x = sx + mx.toInt(); p.y = sy + my.toInt()
                        wm.updateViewLayout(tv, p)
                    }
                }
                MotionEvent.ACTION_UP -> {
                    if (!moved) tv.post { expand() }
                }
            }
            true
        }
        wm.addView(tv, p)
        bubble = tv
        bubbleP = p
    }

    private fun expand() {
        if (!collapsed) return
        val bp = barP
        val p = bubbleP
        if (bp != null && p != null) {
            bp.x = p.x
            bp.y = p.y
            bar?.let { runCatching { wm.updateViewLayout(it, bp) } }
        }
        bubble?.let { runCatching { wm.removeView(it) } }
        bubble = null
        bubbleP = null
        collapsed = false
        bar?.visibility = View.VISIBLE
        markers.values.forEach { it.visibility = if (running) View.INVISIBLE else View.VISIBLE }
    }

    /** Wyłącza panel i automatyczne pokazywanie go po wejściu do gry. */
    private fun powerOff() {
        Store.setAutoEnabled(this, false)
        hideOverlay()
        toast("Panel wyłączony. Automatyczne pokazywanie po wejściu do gry też wyłączone. Włączysz je w aplikacji: „Pokaż panel” albo zaznacz automatykę.")
    }

    private fun realMetrics(): android.util.DisplayMetrics {
        val dm = android.util.DisplayMetrics()
        val d = (getSystemService(DISPLAY_SERVICE) as android.hardware.display.DisplayManager)
            .getDisplay(Display.DEFAULT_DISPLAY)
        @Suppress("DEPRECATION")
        d.getRealMetrics(dm)
        return dm
    }

    /** Przełącza, czy pipeta 💧 i 🎓 zapisują kolory potworów (P), czy przedmiotów (Z). */
    private fun toggleTarget() {
        target = 1 - target
        targetBtn?.text = if (target == 0) "P" else "Z"
        toast(
            if (target == 0) "Cel pipety 💧 i 🎓: POTWORY (kolor ich nazw)"
            else "Cel pipety 💧 i 🎓: PRZEDMIOTY leżące na ziemi"
        )
    }

    /** Zapamiętuje, czy ekran jest teraz poziomo, żeby profile przeliczały pozycje poprawnie. */
    private fun noteOrientation() {
        val dm = android.util.DisplayMetrics()
        val d = (getSystemService(DISPLAY_SERVICE) as android.hardware.display.DisplayManager)
            .getDisplay(Display.DEFAULT_DISPLAY)
        @Suppress("DEPRECATION")
        d.getRealMetrics(dm)
        Store.setLandscape(this, dm.widthPixels > dm.heightPixels)
    }

    private fun saveFrame() {
        val p = frameP ?: return
        updateSettings { it.region = intArrayOf(p.x, p.y, p.x + p.width, p.y + p.height) }
    }

    private fun removeCalibViews() {
        saveFrame()
        learnBase?.recycle()
        learnBase = null
        frame?.let { runCatching { wm.removeView(it) } }
        frame = null
        frameP = null
        cross?.let { runCatching { wm.removeView(it) } }
        cross = null
    }

    private fun setOverlayVisible(v: Boolean) {
        val vis = if (v) View.VISIBLE else View.INVISIBLE
        bar?.visibility = vis
        frame?.visibility = vis
        cross?.visibility = vis
        markers.values.forEach { it.visibility = vis }
    }

    /** Zielona ramka = obszar skanowania. Przeciągasz ją, róg ⇲ zmienia rozmiar. */
    private fun toggleFrame() {
        if (running) return
        if (frame != null) {
            saveFrame()
            frame?.let { runCatching { wm.removeView(it) } }
            frame = null
            frameP = null
            return
        }
        noteOrientation()
        val m = resources.displayMetrics
        val s = Store.loadSettings(this)
        var l = s.region[0]; var t = s.region[1]; var r = s.region[2]; var b = s.region[3]
        if (r <= l || b <= t) {
            l = m.widthPixels / 8; r = m.widthPixels * 7 / 8
            t = m.heightPixels / 5; b = m.heightPixels * 4 / 5
        }
        val p = params(r - l, b - t)
        p.x = l; p.y = t
        val box = FrameLayout(this).apply {
            background = GradientDrawable().apply {
                setColor(0x2200E676); setStroke(dp(3), 0xFF00E676.toInt())
            }
        }
        val handle = TextView(this).apply {
            text = "⇲"; textSize = 22f; setTextColor(Color.WHITE); gravity = Gravity.CENTER
            setBackgroundColor(0xAA00A152.toInt())
        }
        box.addView(handle, FrameLayout.LayoutParams(dp(44), dp(44), Gravity.BOTTOM or Gravity.END))

        var dx = 0f; var dy = 0f; var sx = 0; var sy = 0; var sw = 0; var sh = 0
        var resize = false
        box.setOnTouchListener { v, ev ->
            when (ev.action) {
                MotionEvent.ACTION_DOWN -> {
                    dx = ev.rawX; dy = ev.rawY; sx = p.x; sy = p.y; sw = p.width; sh = p.height
                    resize = ev.x > v.width - dp(56) && ev.y > v.height - dp(56)
                }
                MotionEvent.ACTION_MOVE -> {
                    val mx = (ev.rawX - dx).toInt(); val my = (ev.rawY - dy).toInt()
                    if (resize) {
                        p.width = (sw + mx).coerceAtLeast(dp(80))
                        p.height = (sh + my).coerceAtLeast(dp(80))
                    } else {
                        p.x = sx + mx; p.y = sy + my
                    }
                    wm.updateViewLayout(box, p)
                }
                MotionEvent.ACTION_UP -> saveFrame()
            }
            true
        }
        wm.addView(box, p)
        frame = box
        frameP = p
        toast("Zielona ramka = obszar, w którym szukam potworów i przedmiotów. Przeciągnij ją, róg ⇲ zmienia rozmiar. Stuknij ▢ ponownie, żeby zapisać.")
    }

    /** Krzyżyk-pipeta: przeciągnij na kolor nazwy potwora/przedmiotu i stuknij. */
    private fun toggleCross() {
        if (running) return
        if (cross != null) {
            cross?.let { runCatching { wm.removeView(it) } }
            cross = null
            return
        }
        val size = dp(48)
        val m = resources.displayMetrics
        val tv = TextView(this).apply {
            text = "＋"; gravity = Gravity.CENTER; textSize = 20f
            setTextColor(0xFFFF1744.toInt())
            background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(0x33FFFFFF); setStroke(dp(3), 0xFFFF1744.toInt())
            }
        }
        val p = params(size, size)
        p.x = m.widthPixels / 2 - size / 2
        p.y = m.heightPixels / 2 - size / 2

        var downX = 0f; var downY = 0f; var startX = 0; var startY = 0; var moved = false
        tv.setOnTouchListener { _, ev ->
            when (ev.action) {
                MotionEvent.ACTION_DOWN -> {
                    downX = ev.rawX; downY = ev.rawY; startX = p.x; startY = p.y; moved = false
                }
                MotionEvent.ACTION_MOVE -> {
                    val ddx = ev.rawX - downX; val ddy = ev.rawY - downY
                    if (abs(ddx) > dp(6) || abs(ddy) > dp(6)) moved = true
                    if (moved) {
                        p.x = startX + ddx.toInt(); p.y = startY + ddy.toInt()
                        wm.updateViewLayout(tv, p)
                    }
                }
                MotionEvent.ACTION_UP -> {
                    if (!moved) sampleColor(p.x + size / 2, p.y + size / 2)
                }
            }
            true
        }
        wm.addView(tv, p)
        cross = tv
        toast("Przeciągnij krzyżyk na gruby fragment litery w nazwie potwora lub przedmiotu i stuknij go, żeby zapisać kolor.")
    }

    private fun sampleColor(x: Int, y: Int) {
        if (Build.VERSION.SDK_INT < 30) {
            toast("Wykrywanie wymaga Androida 11 lub nowszego")
            return
        }
        scope.launch {
            setOverlayVisible(false)
            delay(200)
            val bmp = grab()
            setOverlayVisible(true)
            if (bmp == null) {
                toast("Nie udało się zrobić zrzutu ekranu. Wyłącz i włącz usługę Auto Clicker w ułatwieniach dostępu.")
                return@launch
            }
            val c = bmp.getPixel(x.coerceIn(0, bmp.width - 1), y.coerceIn(0, bmp.height - 1))
            bmp.recycle()
            var total = 0
            val forMobs = target == 0
            updateSettings { s ->
                val list = if (forMobs) s.colors else s.lootColors
                if (list.size >= 6) list.removeAt(0)
                list.add(c)
                total = list.size
            }
            toast(
                String.format(
                    "Dodano kolor #%06X do: %s (kolory na liście: %d)",
                    c and 0xFFFFFF, if (forMobs) "potwory" else "przedmioty", total
                )
            )
        }
    }

    /** Zrzut ekranu i policzenie pasujących pikseli, bez uruchamiania klikania. */
    private fun testDetect() {
        if (running) return
        if (Build.VERSION.SDK_INT < 30) {
            toast("Wykrywanie wymaga Androida 11 lub nowszego")
            return
        }
        scope.launch {
            saveFrame()
            settings = Store.loadSettings(this@ClickerService)
            if (settings.colors.isEmpty() && settings.lootColors.isEmpty()) {
                toast("Najpierw dodaj kolory przyciskiem 💧 (P = potwory, Z = przedmioty) albo 🎓")
                return@launch
            }
            setOverlayVisible(false)
            delay(200)
            val bmp = grab()
            setOverlayVisible(true)
            if (bmp == null) {
                toast("Nie udało się zrobić zrzutu ekranu. Wyłącz i włącz usługę Auto Clicker w ułatwieniach dostępu.")
                return@launch
            }
            val s = settings
            val (m, l) = withContext(Dispatchers.Default) {
                Pair(
                    if (s.colors.isEmpty()) -1 else scan(bmp, s, s.colors, null),
                    if (s.lootColors.isEmpty()) -1 else scan(bmp, s, s.lootColors, null)
                )
            }
            bmp.recycle()
            statusTv?.text = "P$m Z$l"
            fun line(name: String, n: Int, min: Int) =
                if (n < 0) "$name: brak zapisanych kolorów"
                else "$name: $n kratek (próg $min) → ${if (n >= min) "SĄ" else "brak"}"
            toast(line("Potwory", m, s.minMob) + "\n" + line("Przedmioty", l, s.minLoot))
        }
    }

    private suspend fun grab(): Bitmap? = suspendCancellableCoroutine<Bitmap?> { cont ->
        if (Build.VERSION.SDK_INT < 30) {
            cont.resume(null)
        } else {
            try {
                takeScreenshot(Display.DEFAULT_DISPLAY, mainExecutor, object : TakeScreenshotCallback {
                    override fun onSuccess(result: ScreenshotResult) {
                        var out: Bitmap? = null
                        try {
                            val hb = result.hardwareBuffer
                            val hw = Bitmap.wrapHardwareBuffer(hb, result.colorSpace)
                            out = hw?.copy(Bitmap.Config.ARGB_8888, false)
                            hw?.recycle()
                            hb.close()
                        } catch (_: Exception) {
                        }
                        if (cont.isActive) cont.resume(out)
                    }

                    override fun onFailure(errorCode: Int) {
                        if (cont.isActive) cont.resume(null)
                    }
                })
            } catch (_: Exception) {
                if (cont.isActive) cont.resume(null)
            }
        }
    }

    /** Obszar własnego panelu sterowania, który pomijamy przy liczeniu. */
    private fun barExclude(): IntArray? {
        val bp = bubbleP
        val bv = bubble
        if (collapsed && bp != null && bv != null) {
            return intArrayOf(bp.x, bp.y, bp.x + bv.width, bp.y + bv.height)
        }
        val p = barP
        val v = bar
        return if (p != null && v != null) intArrayOf(p.x, p.y, p.x + v.width, p.y + v.height) else null
    }

    /**
     * Co ok. 1,2 s robi zrzut i aktualizuje stan: czy na ekranie są potwory i czy leżą przedmioty.
     * Stan „jest" włącza się od razu, a „nie ma" dopiero po goneSec sekundach bez koloru,
     * żeby chwilowe zasłonięcie nazwy nie przerywało bicia.
     */
    private suspend fun detectLoop() {
        while (true) {
            val t0 = SystemClock.elapsedRealtime()
            val bmp = grab()
            if (bmp != null) {
                val s = settings
                val ex = barExclude()
                val (m, l) = withContext(Dispatchers.Default) {
                    Pair(
                        if (s.colors.isEmpty()) 0 else scan(bmp, s, s.colors, ex),
                        if (s.lootColors.isEmpty()) 0 else scan(bmp, s, s.lootColors, ex)
                    )
                }
                bmp.recycle()
                val now = SystemClock.elapsedRealtime()
                val goneMs = s.goneSec * 1000L
                if (m >= s.minMob) {
                    mobsOn = true
                    lastMobSeen = now
                } else if (now - lastMobSeen > goneMs) {
                    mobsOn = false
                }
                if (l >= s.minLoot) {
                    lootOn = true
                    lastLootSeen = now
                } else if (now - lastLootSeen > goneMs) {
                    lootOn = false
                }
                statusTv?.text = "P$m Z$l"
            }
            delay((1200L - (SystemClock.elapsedRealtime() - t0)).coerceAtLeast(150L))
        }
    }

    /**
     * Liczy „kratki" 16x16 px, w których jest gęsto kolorów z listy (tekst nazwy),
     * a nie pojedyncze piksele. Rozproszone piksele tła (piasek, światło) nie zbierają się w gęste
     * kratki, więc wynik jest dużo stabilniejszy niż zwykłe liczenie pikseli.
     */
    private fun scan(bmp: Bitmap, s: Settings, cols: List<Int>, ex: IntArray?): Int {
        val w = bmp.width
        val h = bmp.height
        var l = s.region[0]; var t = s.region[1]; var r = s.region[2]; var b = s.region[3]
        if (r <= l || b <= t) { l = 0; t = 0; r = w; b = h }
        l = l.coerceIn(0, w - 1); t = t.coerceIn(0, h - 1)
        r = r.coerceIn(l + 1, w); b = b.coerceIn(t + 1, h)
        val rw = r - l
        val rh = b - t
        val px = IntArray(rw * rh)
        bmp.getPixels(px, 0, rw, l, t, rw, rh)

        val n = cols.size
        val cr = IntArray(n) { (cols[it] shr 16) and 255 }
        val cg = IntArray(n) { (cols[it] shr 8) and 255 }
        val cb = IntArray(n) { cols[it] and 255 }
        val tol = s.tolerance
        val cw = (rw + CELL - 1) / CELL
        val ch = (rh + CELL - 1) / CELL
        val cells = IntArray(cw * ch)
        for (yy in 0 until rh) {
            val gy = yy + t
            val rowBase = (yy / CELL) * cw
            for (xx in 0 until rw) {
                val gx = xx + l
                if (ex != null && gx >= ex[0] && gx < ex[2] && gy >= ex[1] && gy < ex[3]) continue
                val p = px[yy * rw + xx]
                val pr = (p shr 16) and 255
                val pg = (p shr 8) and 255
                val pb = p and 255
                for (k in 0 until n) {
                    if (abs(pr - cr[k]) <= tol && abs(pg - cg[k]) <= tol && abs(pb - cb[k]) <= tol) {
                        cells[rowBase + xx / CELL]++
                        break
                    }
                }
            }
        }
        var active = 0
        for (c in cells) if (c >= CELL_MIN) active++
        return active
    }

    private suspend fun gesture(x: Int, y: Int, durationMs: Long): Boolean =
        suspendCancellableCoroutine { cont ->
            val path = Path().apply { moveTo(x.toFloat(), y.toFloat()) }
            val stroke = GestureDescription.StrokeDescription(path, 0, durationMs.coerceIn(1L, 60000L))
            val g = GestureDescription.Builder().addStroke(stroke).build()
            val ok = dispatchGesture(g, object : GestureResultCallback() {
                override fun onCompleted(d: GestureDescription?) {
                    if (cont.isActive) cont.resume(true)
                }

                override fun onCancelled(d: GestureDescription?) {
                    if (cont.isActive) cont.resume(false)
                }
            }, null)
            if (!ok && cont.isActive) cont.resume(false)
        }
}
