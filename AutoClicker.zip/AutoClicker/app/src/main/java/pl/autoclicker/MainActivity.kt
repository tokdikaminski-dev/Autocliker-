package pl.autoclicker

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.provider.Settings as AndroidSettings
import android.text.InputType
import android.view.Gravity
import android.app.AlertDialog
import android.content.ClipData
import android.content.ClipboardManager
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.Spinner
import android.widget.CheckBox
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {

    private lateinit var loopsEt: EditText
    private lateinit var tapEt: EditText
    private lateinit var chanCb: CheckBox
    private lateinit var chanEt: EditText
    private lateinit var detCb: CheckBox
    private lateinit var tolEt: EditText
    private lateinit var minEt: EditText
    private lateinit var clearEt: EditText
    private lateinit var colorsTv: TextView
    private lateinit var profileSp: Spinner
    private lateinit var scaleEt: EditText
    private lateinit var extraEt: EditText
    private lateinit var status: TextView

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val s = Store.loadSettings(this)

        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(28), dp(20), dp(28))
        }
        fun text(t: String, size: Float = 14f, bold: Boolean = false) = TextView(this).apply {
            this.text = t; textSize = size; setTextColor(Color.BLACK)
            if (bold) typeface = Typeface.DEFAULT_BOLD
            setPadding(0, dp(8), 0, 0)
        }
        fun num(v: Long) = EditText(this).apply {
            inputType = InputType.TYPE_CLASS_NUMBER; setText(v.toString()); setSingleLine()
        }

        box.addView(text("Auto Clicker", 24f, true))
        status = text("")
        box.addView(status)

        box.addView(text("1. Włącz usługę", 16f, true))
        box.addView(text("Ustawienia → Ułatwienia dostępu → Auto Clicker → włącz. Bez tego aplikacja nie może klikać."))
        box.addView(Button(this).apply {
            text = "Otwórz ustawienia ułatwień dostępu"
            setOnClickListener { startActivity(Intent(AndroidSettings.ACTION_ACCESSIBILITY_SETTINGS)) }
        })

        box.addView(text("2. Ustawienia", 16f, true))
        box.addView(text("Liczba powtórzeń głównej sekwencji (0 = bez końca)"))
        loopsEt = num(s.loops.toLong()); box.addView(loopsEt)
        box.addView(text("Czas zwykłego dotknięcia (ms)"))
        tapEt = num(s.tapMs); box.addView(tapEt)
        chanCb = CheckBox(this).apply { text = "Automatycznie zmieniaj kanał"; isChecked = s.channelEnabled }
        box.addView(chanCb)
        box.addView(text("Zmieniaj kanał co (sekundy)"))
        chanEt = num(s.channelEverySec.toLong()); box.addView(chanEt)

        box.addView(text("Wykrywanie pustego pola (Android 11+)", 16f, true))
        detCb = CheckBox(this).apply {
            text = "Zmieniaj kanał, gdy pole jest puste (zamiast timera)"
            isChecked = s.detectEnabled
        }
        box.addView(detCb)
        box.addView(text("Tolerancja koloru (0-255, zwykle 40-70)"))
        tolEt = num(s.tolerance.toLong()); box.addView(tolEt)
        box.addView(text("Próg: poniżej ilu pikseli pole uznaję za puste"))
        minEt = num(s.minPixels.toLong()); box.addView(minEt)
        box.addView(text("Pole musi być puste przez (sekundy)"))
        clearEt = num(s.clearSec.toLong()); box.addView(clearEt)

        box.addView(text("Czasy (gdy gra się zacina albo wczytuje dłużej)", 16f, true))
        box.addView(text("Mnożnik wszystkich pauz w % (100 = bez zmian, 150 = o połowę dłużej, 200 = dwa razy dłużej)"))
        scaleEt = num(s.pauseScale.toLong()); box.addView(scaleEt)
        box.addView(text("Dodatkowy czas po zmianie kanału (ms), np. 3000 = 3 sekundy więcej na wczytanie"))
        extraEt = num(s.channelExtraMs); box.addView(extraEt)
        colorsTv = text("")
        box.addView(colorsTv)
        box.addView(Button(this).apply {
            text = "Wyczyść zapisane kolory"
            setOnClickListener {
                val st = Store.loadSettings(this@MainActivity)
                st.colors.clear()
                Store.saveSettings(this@MainActivity, st)
                refreshColors()
            }
        })

        box.addView(text("Profile gier", 16f, true))
        box.addView(text("Zapisz bieżące ustawienia (punkty, kolory, ramkę, czasy) jako profil gry i przełączaj się między grami z listy. Profil można skopiować jako tekst i wkleić w innym telefonie."))
        profileSp = Spinner(this)
        box.addView(profileSp)
        box.addView(Button(this).apply {
            text = "Wczytaj wybrany profil"
            setOnClickListener { loadProfile() }
        })
        box.addView(Button(this).apply {
            text = "Zapisz bieżące jako profil…"
            setOnClickListener { saveProfileDialog() }
        })
        box.addView(Button(this).apply {
            text = "Usuń wybrany profil"
            setOnClickListener { deleteProfile() }
        })
        box.addView(Button(this).apply {
            text = "Eksportuj wybrany profil (do schowka)"
            setOnClickListener { exportProfile() }
        })
        box.addView(Button(this).apply {
            text = "Importuj profil ze schowka"
            setOnClickListener { importProfile() }
        })
        box.addView(CheckBox(this).apply {
            text = "Automatycznie wczytuj profil i pokazuj panel po wejściu do gry"
            isChecked = Store.autoEnabled(this@MainActivity)
            setOnCheckedChangeListener { _, c -> Store.setAutoEnabled(this@MainActivity, c) }
        })
        refreshProfiles()

        box.addView(text("3. Panel na ekranie", 16f, true))
        box.addView(text(
            "Po uruchomieniu panelu przejdź do gry.\n" +
                    "＋ dodaje niebieski punkt (główna sekwencja), K＋ dodaje pomarańczowy punkt (zmiana kanału).\n" +
                    "Przeciągnij punkt w miejsce przycisku w grze. Stuknij punkt, żeby ustawić: naciśnij/przytrzymaj, czas trzymania, ile razy i pauzy.\n" +
                    "Zmiana kanału: dodaj punkty K w kolejności klików (np. menu kanałów → wybór kanału → potwierdź). " +
                    "Kilka punktów oznaczonych jako „rotuj” będzie wybieranych na zmianę, czyli za każdym razem inny kanał.\n" +
                    "▶ start, ■ stop, ✥ przesuwanie panelu, ✕ zamknięcie.\n\n" +
                    "Wykrywanie pustego pola:\n" +
                    "▢ pokazuje zieloną ramkę, czyli obszar, w którym szukam potworów i przedmiotów (róg ⇲ zmienia rozmiar). Stuknij ▢ ponownie, żeby zapisać.\n" +
                    "💧 pokazuje krzyżyk: przeciągnij go na gruby fragment litery w nazwie potwora (albo przedmiotu na ziemi) i stuknij. Zapisz tak każdy kolor, który ma liczyć się jako „pole zajęte”.\n" +
                    "🔍 robi próbny zrzut i pokazuje, ile pikseli pasuje. Przy potworach na ekranie liczba ma być duża (powyżej progu), a przy pustym polu mała (poniżej progu).\n" +
                    "🎓 kalibruje kolory automatycznie: stuknij raz na pustym polu, potem drugi raz, gdy są potwory i przedmioty z widocznymi nazwami.\n" +
                    "Podczas pracy liczba pikseli widać na panelu obok ✕."
        ))
        box.addView(Button(this).apply {
            text = "Pokaż panel"
            setOnClickListener { showPanel() }
        })
        box.addView(Button(this).apply {
            text = "Ukryj panel"
            setOnClickListener { ClickerService.instance?.hideOverlay() }
        })

        setContentView(ScrollView(this).apply { addView(box) })
    }

    override fun onResume() {
        super.onResume()
        refreshColors()
        status.text = if (ClickerService.instance != null) "Usługa: włączona ✔" else "Usługa: wyłączona ✘"
        status.setTextColor(if (ClickerService.instance != null) 0xFF2E7D32.toInt() else 0xFFD32F2F.toInt())
    }

    override fun onPause() {
        super.onPause()
        saveSettings()
    }

    private fun toast(t: String) {
        Toast.makeText(this, t, Toast.LENGTH_LONG).show()
    }

    /** Odświeża pola ekranu głównego wartościami zapisanymi w pamięci (po wczytaniu profilu). */
    private fun fillFields() {
        val s = Store.loadSettings(this)
        loopsEt.setText(s.loops.toString())
        tapEt.setText(s.tapMs.toString())
        chanCb.isChecked = s.channelEnabled
        chanEt.setText(s.channelEverySec.toString())
        detCb.isChecked = s.detectEnabled
        tolEt.setText(s.tolerance.toString())
        minEt.setText(s.minPixels.toString())
        clearEt.setText(s.clearSec.toString())
        scaleEt.setText(s.pauseScale.toString())
        extraEt.setText(s.channelExtraMs.toString())
    }

    private fun refreshProfiles(select: String? = null) {
        val names = Profiles.names(this)
        val ad = ArrayAdapter(
            this, android.R.layout.simple_spinner_item,
            if (names.isEmpty()) listOf("(brak profili)") else names
        )
        ad.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        profileSp.adapter = ad
        if (select != null) {
            val i = names.indexOf(select)
            if (i >= 0) profileSp.setSelection(i)
        }
    }

    private fun selectedProfile(): String? {
        val n = profileSp.selectedItem as? String ?: return null
        return if (Profiles.names(this).contains(n)) n else null
    }

    private fun loadProfile() {
        val n = selectedProfile() ?: return toast("Najpierw wybierz profil z listy")
        val json = Profiles.get(this, n) ?: return toast("Nie znaleziono profilu")
        ClickerService.instance?.hideOverlay()
        if (Profiles.load(this, json)) {
            Store.setActiveProfile(this, n)
            fillFields()
            refreshColors()
            toast("Wczytano profil „$n”. Naciśnij Pokaż panel.")
        } else {
            toast("Profil jest uszkodzony")
        }
    }

    private fun saveProfileDialog() {
        saveSettings()
        val et = EditText(this).apply {
            hint = "np. Metin2 – farmienie"
            setSingleLine()
        }
        AlertDialog.Builder(this)
            .setTitle("Nazwa profilu")
            .setView(et)
            .setPositiveButton("Zapisz") { _, _ ->
                val name = et.text.toString().trim().take(40)
                if (name.isEmpty()) {
                    toast("Podaj nazwę profilu")
                } else {
                    Profiles.put(this, name, Profiles.snapshot(this, name))
                    Store.setActiveProfile(this, name)
                    refreshProfiles(name)
                    toast("Zapisano profil „$name”")
                }
            }
            .setNegativeButton("Anuluj", null)
            .show()
    }

    private fun deleteProfile() {
        val n = selectedProfile() ?: return toast("Najpierw wybierz profil z listy")
        if (Profiles.isBuiltin(n)) return toast("Profil wbudowany nie jest usuwany")
        AlertDialog.Builder(this)
            .setTitle("Usunąć profil „$n”?")
            .setPositiveButton("Usuń") { _, _ ->
                Profiles.delete(this, n)
                refreshProfiles()
            }
            .setNegativeButton("Anuluj", null)
            .show()
    }

    private fun exportProfile() {
        val n = selectedProfile() ?: return toast("Najpierw wybierz profil z listy")
        val json = Profiles.get(this, n) ?: return toast("Nie znaleziono profilu")
        val cm = getSystemService(CLIPBOARD_SERVICE) as ClipboardManager
        cm.setPrimaryClip(ClipData.newPlainText("profil", json))
        toast("Skopiowano profil do schowka. Wklej go w wiadomości.")
    }

    private fun importProfile() {
        val cm = getSystemService(CLIPBOARD_SERVICE) as ClipboardManager
        val clip = cm.primaryClip
        val text = if (clip != null && clip.itemCount > 0)
            clip.getItemAt(0).coerceToText(this)?.toString() else null
        if (text.isNullOrBlank()) return toast("Schowek jest pusty")
        val name = Profiles.importJson(this, text)
            ?: return toast("Schowek nie zawiera poprawnego profilu")
        refreshProfiles(name)
        toast("Zaimportowano profil „$name”. Stuknij „Wczytaj wybrany profil”.")
    }

    private fun refreshColors() {
        val n = Store.loadSettings(this).colors.size
        colorsTv.text = "Aktywny profil: ${Store.activeProfile(this) ?: "brak"}\nZapisane kolory do wykrywania: $n"
    }

    private fun saveSettings() {
        // wczytujemy zapisane ustawienia, żeby nie skasować kolorów i obszaru ustawionych z panelu
        val st = Store.loadSettings(this)
        st.loops = loopsEt.text.toString().toIntOrNull() ?: 0
        st.channelEnabled = chanCb.isChecked
        st.channelEverySec = (chanEt.text.toString().toIntOrNull() ?: 300).coerceAtLeast(1)
        st.tapMs = (tapEt.text.toString().toLongOrNull() ?: 50L).coerceAtLeast(1L)
        st.detectEnabled = detCb.isChecked
        st.tolerance = (tolEt.text.toString().toIntOrNull() ?: 50).coerceIn(0, 255)
        st.minPixels = (minEt.text.toString().toIntOrNull() ?: 30).coerceAtLeast(1)
        st.clearSec = (clearEt.text.toString().toIntOrNull() ?: 3).coerceAtLeast(1)
        st.pauseScale = (scaleEt.text.toString().toIntOrNull() ?: 100).coerceIn(10, 1000)
        st.channelExtraMs = (extraEt.text.toString().toLongOrNull() ?: 0L).coerceAtLeast(0L)
        Store.saveSettings(this, st)
    }

    private fun showPanel() {
        saveSettings()
        val svc = ClickerService.instance
        if (svc == null) {
            Toast.makeText(this, "Najpierw włącz usługę w ustawieniach ułatwień dostępu", Toast.LENGTH_LONG).show()
            return
        }
        svc.showOverlay()
        moveTaskToBack(true)
    }
}
