package pl.autoclicker

import android.content.Context
import android.graphics.Color
import android.hardware.display.DisplayManager
import android.util.DisplayMetrics
import org.json.JSONArray
import org.json.JSONObject
import kotlin.math.max
import kotlin.math.min

enum class ActionType { TAP, HOLD }

/** MAIN = główna sekwencja klikania, CHANNEL = sekwencja zmiany kanału. */
enum class Group { MAIN, CHANNEL }

/** Kiedy wykonywać punkt: zawsze albo tylko gdy wykryto potwory / przedmioty. */
enum class Cond { ALWAYS, MOBS, LOOT }

class Step(
    var x: Int,
    var y: Int,
    var group: Group = Group.MAIN,
    var type: ActionType = ActionType.TAP,
    var holdMs: Long = 500,        // jak długo trzymać (tryb HOLD)
    var count: Int = 1,            // ile razy nacisnąć
    var gapMs: Long = 100,         // przerwa między kolejnymi naciśnięciami
    var delayAfterMs: Long = 500,  // pauza po tym punkcie
    var rotate: Boolean = false,   // tylko CHANNEL: punkty "rotate" wykonywane na zmianę
    var cond: Cond = Cond.ALWAYS,  // warunek wykonania (tylko gdy są potwory / przedmioty)
)

class Settings(
    var loops: Int = 0,               // 0 = bez końca
    var channelEnabled: Boolean = false,
    var channelEverySec: Int = 300,   // co ile sekund zmieniać kanał
    var tapMs: Long = 50,             // czas zwykłego dotknięcia
    var detectEnabled: Boolean = false, // zmiana kanału po wykryciu pustego pola
    var tolerance: Int = 30,          // tolerancja koloru (0-255)
    var minMob: Int = 12,             // ile "kratek" z kolorem nazwy = są potwory
    var minLoot: Int = 8,             // ile "kratek" z kolorem nazwy = leży przedmiot
    var clearSec: Int = 3,            // przez ile sekund pole musi być puste (zmiana kanału)
    var goneSec: Int = 2,             // po ilu sekundach bez koloru uznajemy, że potwora/przedmiotu nie ma
    var pauseScale: Int = 100,        // mnożnik wszystkich pauz w % (100 = bez zmian)
    var channelExtraMs: Long = 0,     // dodatkowy czas po zmianie kanału (wczytywanie)
    var region: IntArray = intArrayOf(0, 0, 0, 0), // obszar skanowania l,t,r,b
    var colors: MutableList<Int> = mutableListOf(),     // kolory nazw potworów
    var lootColors: MutableList<Int> = mutableListOf(), // kolory nazw przedmiotów na ziemi
)

object Store {
    private fun prefs(c: Context) = c.getSharedPreferences("autoclicker", Context.MODE_PRIVATE)

    fun loadSteps(c: Context): MutableList<Step> {
        val out = mutableListOf<Step>()
        val raw = prefs(c).getString("steps", null) ?: return out
        try {
            val arr = JSONArray(raw)
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                out.add(
                    Step(
                        x = o.getInt("x"),
                        y = o.getInt("y"),
                        group = Group.valueOf(o.getString("group")),
                        type = ActionType.valueOf(o.getString("type")),
                        holdMs = o.getLong("holdMs"),
                        count = o.getInt("count"),
                        gapMs = o.getLong("gapMs"),
                        delayAfterMs = o.getLong("delayAfterMs"),
                        rotate = o.optBoolean("rotate", false),
                        cond = Cond.valueOf(o.optString("cond", "ALWAYS")),
                    )
                )
            }
        } catch (_: Exception) {
        }
        return out
    }

    fun saveSteps(c: Context, steps: List<Step>) {
        val arr = JSONArray()
        steps.forEach {
            arr.put(
                JSONObject()
                    .put("x", it.x).put("y", it.y)
                    .put("group", it.group.name).put("type", it.type.name)
                    .put("holdMs", it.holdMs).put("count", it.count)
                    .put("gapMs", it.gapMs).put("delayAfterMs", it.delayAfterMs)
                    .put("rotate", it.rotate).put("cond", it.cond.name)
            )
        }
        prefs(c).edit().putString("steps", arr.toString()).apply()
    }

    /** Automatyczne wczytywanie profilu i pokazywanie panelu po wejściu do gry. */
    fun autoEnabled(c: Context): Boolean = prefs(c).getBoolean("auto", true)

    fun setAutoEnabled(c: Context, v: Boolean) {
        prefs(c).edit().putBoolean("auto", v).apply()
    }

    fun activeProfile(c: Context): String? = prefs(c).getString("activeProfile", null)

    fun setActiveProfile(c: Context, name: String?) {
        prefs(c).edit().putString("activeProfile", name).apply()
    }

    /** Profil przypisany do pakietu (gry). */
    fun boundProfile(c: Context, pkg: String): String? = prefs(c).getString("bind:$pkg", null)

    fun bind(c: Context, pkg: String, name: String) {
        prefs(c).edit().putString("bind:$pkg", name).apply()
    }

    /** Czy punkty zostały ustawione w poziomie (gra w trybie landscape). */
    fun isLandscape(c: Context): Boolean = prefs(c).getBoolean("landscape", true)

    fun setLandscape(c: Context, v: Boolean) {
        prefs(c).edit().putBoolean("landscape", v).apply()
    }

    fun loadSettings(c: Context): Settings {
        val p = prefs(c)
        val reg = (p.getString("region", "") ?: "").split(",").mapNotNull { it.toIntOrNull() }
        val cols = (p.getString("colors", "") ?: "").split(",").mapNotNull { it.toIntOrNull() }
        val loot = (p.getString("lootColors", "") ?: "").split(",").mapNotNull { it.toIntOrNull() }
        return Settings(
            loops = p.getInt("loops", 0),
            channelEnabled = p.getBoolean("chEnabled", false),
            channelEverySec = p.getInt("chEvery", 300),
            tapMs = p.getLong("tapMs", 50),
            detectEnabled = p.getBoolean("detect", false),
            tolerance = p.getInt("tol", 30),
            minMob = p.getInt("minMob", 12),
            minLoot = p.getInt("minLoot", 8),
            clearSec = p.getInt("clearSec", 3),
            goneSec = p.getInt("goneSec", 2),
            pauseScale = p.getInt("pauseScale", 100),
            channelExtraMs = p.getLong("chExtra", 0),
            region = if (reg.size == 4) reg.toIntArray() else intArrayOf(0, 0, 0, 0),
            colors = cols.toMutableList(),
            lootColors = loot.toMutableList(),
        )
    }

    fun saveSettings(c: Context, s: Settings) {
        prefs(c).edit()
            .putInt("loops", s.loops)
            .putBoolean("chEnabled", s.channelEnabled)
            .putInt("chEvery", s.channelEverySec)
            .putLong("tapMs", s.tapMs)
            .putBoolean("detect", s.detectEnabled)
            .putInt("tol", s.tolerance)
            .putInt("minMob", s.minMob)
            .putInt("minLoot", s.minLoot)
            .putInt("clearSec", s.clearSec)
            .putInt("goneSec", s.goneSec)
            .putInt("pauseScale", s.pauseScale)
            .putLong("chExtra", s.channelExtraMs)
            .putString("region", s.region.joinToString(","))
            .putString("colors", s.colors.joinToString(","))
            .putString("lootColors", s.lootColors.joinToString(","))
            .apply()
    }
}

/**
 * Profile gier: zapisane zestawy punktów, kolorów, ramki i czasów.
 * Pozycje są trzymane jako ułamki ekranu (0.0-1.0), więc profil działa na różnych telefonach.
 */
object Profiles {
    private fun prefs(c: Context) = c.getSharedPreferences("profiles", Context.MODE_PRIVATE)

    const val METIN = "Metin2 Pandora (wbudowany)"

    // Kolory i progi dobrane ze zrzutów ekranu: nazwy potworów (ciemna czerwień) i nazwy
    // przedmiotów na ziemi (żółte). Liczymy "kratki" 16x16 px z gęstym kolorem nazwy:
    // potwory: puste pole 0, bez potworów 2, tłum 82 (próg 12);
    // przedmioty: puste pole 3, jeden przedmiot 16, trzy 55 (próg 8).
    private val METIN_JSON = """
{
 "name": "Metin2 Pandora (wbudowany)",
 "v": 1,
 "landscape": true,
 "steps": [
  {"x":0.809,"y":0.721,"group":"MAIN","type":"TAP","count":1,"delayAfterMs":400,"cond":"MOBS"},
  {"x":0.873,"y":0.628,"group":"MAIN","type":"HOLD","holdMs":1500,"count":1,"delayAfterMs":300,"cond":"MOBS"},
  {"x":0.930,"y":0.725,"group":"MAIN","type":"TAP","count":3,"gapMs":300,"delayAfterMs":500,"cond":"LOOT"},
  {"x":0.845,"y":0.080,"group":"CHANNEL","type":"TAP","count":1,"delayAfterMs":1200},
  {"x":0.560,"y":0.392,"group":"CHANNEL","type":"TAP","count":1,"delayAfterMs":8000,"rotate":true},
  {"x":0.560,"y":0.479,"group":"CHANNEL","type":"TAP","count":1,"delayAfterMs":8000,"rotate":true},
  {"x":0.560,"y":0.564,"group":"CHANNEL","type":"TAP","count":1,"delayAfterMs":8000,"rotate":true},
  {"x":0.560,"y":0.651,"group":"CHANNEL","type":"TAP","count":1,"delayAfterMs":8000,"rotate":true},
  {"x":0.560,"y":0.737,"group":"CHANNEL","type":"TAP","count":1,"delayAfterMs":8000,"rotate":true}
 ],
 "region": [0.25, 0.10, 0.76, 0.80],
 "colors": ["#B23C32"],
 "lootColors": ["#F8F888"],
 "loops": 0,
 "tapMs": 50,
 "channelEnabled": true,
 "channelEverySec": 300,
 "detectEnabled": true,
 "tolerance": 30,
 "minMob": 12,
 "minLoot": 8,
 "clearSec": 3,
 "goneSec": 2
}
"""

    private val builtin: Map<String, String> = mapOf(METIN to METIN_JSON)

    // fragmenty nazwy pakietu, po których rozpoznajemy grę dla profilu wbudowanego
    private val hints: Map<String, List<String>> =
        mapOf(METIN to listOf("pandora", "metin", "mt2"))

    fun isBuiltin(name: String): Boolean = builtin.containsKey(name)

    fun builtinFor(pkg: String): String? {
        val p = pkg.lowercase()
        return hints.entries.firstOrNull { e -> e.value.any { p.contains(it) } }?.key
    }

    fun names(c: Context): List<String> =
        (builtin.keys + prefs(c).all.keys).toSortedSet().toList()

    fun get(c: Context, name: String): String? =
        prefs(c).getString(name, null) ?: builtin[name]

    fun put(c: Context, name: String, json: String) {
        prefs(c).edit().putString(name, json).apply()
    }

    fun delete(c: Context, name: String) {
        prefs(c).edit().remove(name).apply()
    }

    /** Rozmiar ekranu w orientacji, w której ustawiano punkty. */
    private fun screenSize(c: Context, landscape: Boolean): Pair<Int, Int> {
        val dm = DisplayMetrics()
        val d = (c.getSystemService(Context.DISPLAY_SERVICE) as DisplayManager).getDisplay(0)
        @Suppress("DEPRECATION")
        d.getRealMetrics(dm)
        val big = max(dm.widthPixels, dm.heightPixels)
        val small = min(dm.widthPixels, dm.heightPixels)
        return if (landscape) Pair(big, small) else Pair(small, big)
    }

    /** Zamienia bieżące ustawienia robocze na tekst JSON profilu. */
    fun snapshot(c: Context, name: String): String {
        val land = Store.isLandscape(c)
        val (sw, sh) = screenSize(c, land)
        val s = Store.loadSettings(c)
        val o = JSONObject()
        o.put("name", name)
        o.put("v", 1)
        o.put("landscape", land)
        val arr = JSONArray()
        Store.loadSteps(c).forEach { st ->
            arr.put(
                JSONObject()
                    .put("x", st.x.toDouble() / sw).put("y", st.y.toDouble() / sh)
                    .put("group", st.group.name).put("type", st.type.name)
                    .put("holdMs", st.holdMs).put("count", st.count)
                    .put("gapMs", st.gapMs).put("delayAfterMs", st.delayAfterMs)
                    .put("rotate", st.rotate).put("cond", st.cond.name)
            )
        }
        o.put("steps", arr)
        val reg = JSONArray()
        reg.put(s.region[0].toDouble() / sw).put(s.region[1].toDouble() / sh)
        reg.put(s.region[2].toDouble() / sw).put(s.region[3].toDouble() / sh)
        o.put("region", reg)
        o.put("colors", JSONArray(s.colors))
        o.put("lootColors", JSONArray(s.lootColors))
        o.put("loops", s.loops)
        o.put("tapMs", s.tapMs)
        o.put("channelEnabled", s.channelEnabled)
        o.put("channelEverySec", s.channelEverySec)
        o.put("detectEnabled", s.detectEnabled)
        o.put("tolerance", s.tolerance)
        o.put("minMob", s.minMob)
        o.put("minLoot", s.minLoot)
        o.put("clearSec", s.clearSec)
        o.put("goneSec", s.goneSec)
        o.put("pauseScale", s.pauseScale)
        o.put("channelExtraMs", s.channelExtraMs)
        return o.toString(2)
    }

    /** Wczytuje profil do ustawień roboczych. Zwraca false, jeśli tekst jest uszkodzony. */
    fun load(c: Context, json: String): Boolean {
        return try {
            val o = JSONObject(json)
            val land = o.optBoolean("landscape", true)
            val (sw, sh) = screenSize(c, land)

            val steps = mutableListOf<Step>()
            val arr = o.optJSONArray("steps") ?: JSONArray()
            for (i in 0 until arr.length()) {
                val t = arr.getJSONObject(i)
                steps.add(
                    Step(
                        x = (t.getDouble("x") * sw).toInt(),
                        y = (t.getDouble("y") * sh).toInt(),
                        group = Group.valueOf(t.optString("group", "MAIN")),
                        type = ActionType.valueOf(t.optString("type", "TAP")),
                        holdMs = t.optLong("holdMs", 500),
                        count = t.optInt("count", 1),
                        gapMs = t.optLong("gapMs", 100),
                        delayAfterMs = t.optLong("delayAfterMs", 500),
                        rotate = t.optBoolean("rotate", false),
                        cond = Cond.valueOf(t.optString("cond", "ALWAYS")),
                    )
                )
            }

            val reg = o.optJSONArray("region")
            val region = if (reg != null && reg.length() == 4) {
                intArrayOf(
                    (reg.getDouble(0) * sw).toInt(), (reg.getDouble(1) * sh).toInt(),
                    (reg.getDouble(2) * sw).toInt(), (reg.getDouble(3) * sh).toInt()
                )
            } else intArrayOf(0, 0, 0, 0)

            val cols = parseColors(o.optJSONArray("colors"))
            val lootCols = parseColors(o.optJSONArray("lootColors"))

            val s = Settings(
                loops = o.optInt("loops", 0),
                channelEnabled = o.optBoolean("channelEnabled", false),
                channelEverySec = o.optInt("channelEverySec", 300),
                tapMs = o.optLong("tapMs", 50),
                detectEnabled = o.optBoolean("detectEnabled", false),
                tolerance = o.optInt("tolerance", 30),
                minMob = o.optInt("minMob", 12),
                minLoot = o.optInt("minLoot", 8),
                clearSec = o.optInt("clearSec", 3),
                goneSec = o.optInt("goneSec", 2),
                pauseScale = o.optInt("pauseScale", 100),
                channelExtraMs = o.optLong("channelExtraMs", 0),
                region = region,
                colors = cols,
                lootColors = lootCols,
            )
            Store.setLandscape(c, land)
            Store.saveSteps(c, steps)
            Store.saveSettings(c, s)
            true
        } catch (_: Exception) {
            false
        }
    }

    /** Kolory: liczby (ARGB) albo teksty typu "#FF8800". */
    private fun parseColors(a: JSONArray?): MutableList<Int> {
        val out = mutableListOf<Int>()
        if (a != null) {
            for (i in 0 until a.length()) {
                val v = a.get(i)
                out.add(if (v is String) Color.parseColor(v) else (v as Number).toInt())
            }
        }
        return out
    }

    /** Dodaje profil wklejony jako tekst. Zwraca nazwę profilu albo null. */
    fun importJson(c: Context, text: String): String? {
        val a = text.indexOf('{')
        val b = text.lastIndexOf('}')
        if (a < 0 || b <= a) return null
        val clean = text.substring(a, b + 1)
        return try {
            val name = JSONObject(clean).optString("name", "").trim()
            if (name.isEmpty()) null else {
                put(c, name, clean)
                name
            }
        } catch (_: Exception) {
            null
        }
    }
}
